import pandas as pd
import numpy as np
import torch
import torch.nn.functional as F
from haversine import haversine, haversine_vector
import pickle
import os

def data_prep(reviews_data,
              user_cluster = 'Philadelphia, PA Area',
              user_selection = [
                    {"name": "Philly Foodworks", "food": "1", "time": "2", "service": "3"},
                    {"name": "Ice Cave", "food": "1", "time": "2", "service": "3"},
                    {"name": "Kims Restaurant", "food": "1", "time": "2", "service": "3"},
                ]):
    
    user_rest_names = [item["name"] for item in user_selection]
    
    ####### MF model data prep #######
    # convert restaurant names to resIds for MF model
    user_restaurant_ids = list(reviews_data[reviews_data.business_name.isin(user_rest_names)]['resId'].drop_duplicates())
    
    data_2 = reviews_data[['userId', 'resId', 'rating']] # subset to only required cols for training
    
    # add user and list of user-preferred restaurants to data
    new_userId = max(data_2['userId']) + 1
    new_user_df = pd.DataFrame({
        "userId": [new_userId] * len(user_restaurant_ids),
        "resId": user_restaurant_ids,
        "rating": 5
    })
    data_3 = pd.concat([data_2, new_user_df])

    train_data = encode_data(data_3)
    
    # generate set of all restaurants in user's cluster for prediction
    rests_in_cluster = reviews_data[reviews_data.cluster_name == user_cluster]
    res_ids_in_cluster = list(set(rests_in_cluster.resId.values) - set(user_restaurant_ids)) # don't include restaurants that user already chose
    new_user = torch.LongTensor([new_userId] * len(res_ids_in_cluster))
    res_ids_in_cluster = torch.LongTensor(res_ids_in_cluster)

    ####### sentiment model data prep #######
    senti_data = reviews_data[['user_id', 'business_id', 'time', 'service', 'food']]
    senti_data['time'] = senti_data['time'] * 2 + 1
    senti_data['service'] = senti_data['service'] * 2 + 1
    senti_data['food'] = senti_data['food'] * 2 + 1

    # add new user data
    user_reviews_subset = reviews_data[reviews_data.business_name.isin(user_rest_names)][['business_id', 'business_name']].drop_duplicates() 
    new_user_df_senti = pd.DataFrame({
        "user_id": [new_userId] * len(user_rest_names),
        "business_name": user_rest_names,
        "time": [item["time"] for item in user_selection],
        "service": [item["service"] for item in user_selection],
        "food": [item["food"] for item in user_selection],
    })
    new_user_df_senti = new_user_df_senti.merge(user_reviews_subset, on='business_name')[['user_id', 'business_id', 'time', 'service', 'food']]
    senti_data_2 = pd.concat([senti_data, new_user_df_senti])
    senti_data_2['Avg_sentiment'] = senti_data_2.apply(lambda row : w_sentiment(row['time'],row['service'],row['food']),axis = 1)

    senti_user_list = list(senti_data_2['user_id'])  # list of user IDs
    senti_item_list = list(senti_data_2['business_id'])  # list of item IDs
    senti_ratings_list = list(senti_data_2['Avg_sentiment'])  # list of corresponding ratings

    # generate set of all restaurants in user's cluster for prediction
    bus_ids_in_cluster = list(set(rests_in_cluster.business_id.values) - set(new_user_df_senti['business_id'])) # don't include restaurants that user already chose
    
    return train_data, new_user, res_ids_in_cluster, senti_user_list, senti_item_list, senti_ratings_list, bus_ids_in_cluster

def proc_col(col, train_col=None):
    """
    Assigns unique continuous IDs to the values in a pandas column.
    """
    if train_col is not None:
        uniq = train_col.unique()
    else:
        uniq = col.unique()
    name2idx = {o:i for i,o in enumerate(uniq)}
    return name2idx, np.array([name2idx.get(x, -1) for x in col]), len(uniq)

def encode_data(df, train=None):
    """
    Transforms rating data by assigning continuous IDs to users and movies. 
    If a training dataset is provided, it applies the same encoding scheme as used in the training data.
    """
    df = df.copy()
    for col_name in ["userId", "resId"]:
        train_col = None
        if train is not None:
            train_col = train[col_name]
        _,col,_ = proc_col(df[col_name], train_col)
        df[col_name] = col
        df = df[df[col_name] >= 0]
    return df

def train_epocs(model, df, epochs=10, lr=0.01, wd=0.0):
    optimizer = torch.optim.Adam(model.parameters(), lr=lr, weight_decay=wd)
    model.train()
    for _ in range(epochs):
        users = torch.LongTensor(df.userId.values)
        items = torch.LongTensor(df.resId.values)
        ratings = torch.FloatTensor(df.rating.values)
        y_hat = model(users, items)
        loss = F.mse_loss(y_hat, ratings)
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()


def rests_dd(cluster_name = 'Philadelphia, PA Area') -> list:
    '''
    Function to populate restaurant dropdown in frontend
    Returns top 50 rated restaurants (by name) in user's location cluster from raw data, for user to choose from
    '''
    data = pd.read_csv('reviews_restaurant_indexed_clusters_agg.csv') # already aggregated by business name and filtered for businesses with 100 or more reviews

    data_2 = data[data.cluster_name == cluster_name] 
    data_3 = data_2.sort_values(by='avg_rating', ascending=False)
    
    top_rests_in_cluster = list(data_3['business_name'][0:50])

    return top_rests_in_cluster

def get_nearest_cluster(user_lat: float, user_lon: float) -> str:
    '''
    Function to return nearest cluster name given user lat/lon coordinates
    '''

    # cluster centers from trained kmeans algo done prior to runtime; see "add cluster to data.ipynb"
    CLUSTER_CENTERS = \
        np.array([[  39.99196076,  -75.19358042],
                [  27.95210395,  -82.5794312 ],
                [  29.95587874,  -90.08654389],
                [  36.13321563,  -86.76483624],
                [  38.63318296,  -90.28916815],
                [  39.82630033,  -86.14832554],
                [  32.25073449, -110.93573172],
                [  34.42135777, -119.71599241],
                [  39.51233226, -119.79426736],
                [  43.61817079, -116.27143892],
                [  53.52984855, -113.5089529 ]])
   
    # predefined cluster names
    CLUSTER_NAMES = ['Philadelphia, PA Area',
                    'Tampa Bay, FL Area',
                    'New Orleans, LA Area',
                    'Nashville Area',
                    'St Louis, Area',
                    'Indianapolis, IN Area',
                    'Tucson, AZ Area',
                    'Los Angeles, CA Area',
                    'Reno, NV Area',
                    'Boise, ID Area',
                    'Edmonton, CN Area',]
    
    distances = []
    user_loc_new = [(user_lat, user_lon)]*11
    CLUSTER_CENTERS_VECTORS = [(center[0], center[1]) for center in CLUSTER_CENTERS]
    distances.append(haversine_vector(user_loc_new, CLUSTER_CENTERS_VECTORS))
    
    return CLUSTER_NAMES[distances.index(min(distances))]

def loading_review(folder_path): # function to read all review sentiment pickle files 
    folder_path = folder_path
    all_review_sentiment= []
    for filename in os.listdir(folder_path): 
        file_path = os.path.join(folder_path,filename)
        with open (file_path,'rb') as file: 
            review_sentiment = pickle.load(file)
            all_review_sentiment.append(review_sentiment)
    # Concatenate all DataFrames in the list
    review_sentiment = pd.concat([pd.DataFrame(df) for df in all_review_sentiment], ignore_index=True)
    return review_sentiment

def w_sentiment(x,y,z):
    sorted_list = sorted([float(x),float(y),float(z)])
    return sorted_list[0] * 0.1 + sorted_list[1] * 0.3 + sorted_list[2] * 0.6

def torch_sentiment_predict_batch(user_list, item_list, user_encoder, item_encoder, user_item_matrix, k=5, chunk_size=100):
    # Encode all users and items in batch
    encoded_users = user_encoder.transform(user_list)
    encoded_items = item_encoder.transform(item_list)

    # Initialize list to store predictions for each (user, item) pair
    predictions = []

    # Step 1: Get all user rating rows in batch
    user_ratings_matrix = torch.tensor(
        user_item_matrix[encoded_users].toarray()
        #, device="cuda"
    )

    # Step 2: Get all item rating columns in batch
    item_ratings_matrix = torch.tensor(
        user_item_matrix[:, encoded_items].toarray()
        #, device="cuda"
    ).transpose(0, 1)  # Transpose for easier indexing by item

    # Step 3: Process each user-item pair in the batch
    for idx in range(len(user_list)):
        user_ratings = user_ratings_matrix[idx]  # Get ratings for the current user
        user_rated_items = torch.nonzero(user_ratings, as_tuple=True)[0]

        if user_rated_items.numel() == 0:
            predictions.append((user_list[idx], item_list[idx], 0))  # No ratings found
            continue

        item_ratings = item_ratings_matrix[idx]  # Get ratings for the current item
        item_rated_users = torch.nonzero(item_ratings, as_tuple=True)[0]

        if item_rated_users.numel() == 0:
            predictions.append((user_list[idx], item_list[idx], 0))  # No users rated the item
            continue

        # Find common users and calculate similarities
        common_users = torch.cat((user_rated_items, item_rated_users)).unique()
        
        # Initialize to hold top-K similarities across chunks
        top_k_similarities = torch.tensor([]
                                          #, device="cuda"
                                          )
        top_k_indices = torch.tensor([], dtype=torch.long#, device="cuda"
                                     )

        # Process common users in chunks to manage memory
        for i in range(0, len(common_users), chunk_size):
        
            chunk_users = common_users[i:i + chunk_size].cpu()
            chunk_user_ratings_cpu = user_item_matrix[chunk_users].toarray()
            chunk_user_ratings = torch.tensor(chunk_user_ratings_cpu
                                              #, device="cuda"
                                              )

                
            # Calculate cosine similarities
            user_vector = user_ratings / user_ratings.norm()
            chunk_similarities = torch.mm(chunk_user_ratings, user_vector.view(-1, 1)).squeeze()
            
            
            if chunk_similarities.dim() == 0:
                chunk_similarities = chunk_similarities.unsqueeze(0)

            # Aggregate top-K similarities
            combined_similarities = torch.cat((top_k_similarities, chunk_similarities))
            combined_indices = torch.cat((top_k_indices, chunk_users
                                          #.to("cuda")
                                          ))

            # Get top-K from combined similarities
            if combined_similarities.numel() > k:
                top_k_similarities, indices = torch.topk(combined_similarities, k)
                top_k_indices = combined_indices[indices]
            else:
                top_k_similarities = combined_similarities
                top_k_indices = combined_indices

        # Predict rating using top-K similarities
        top_k_ratings = item_ratings[top_k_indices]
        weighted_sum = (top_k_similarities * top_k_ratings).sum()
        normalization_factor = top_k_similarities.sum()
        predicted_rating = (weighted_sum / normalization_factor).cpu().item() if normalization_factor != 0 else 0

        predictions.append((user_list[idx], item_list[idx],predicted_rating))
        torch.cuda.empty_cache()
        
    return predictions
