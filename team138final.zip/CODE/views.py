import pandas as pd
import numpy as np
from helper import data_prep
from models import get_mf_preds, get_senti_preds
from flask import Blueprint, request, jsonify

import time

views = Blueprint("views", __name__)


@views.route('/api/generate-recs/', methods=["POST"])
def generate_recs(reviews_path='reviews_restaurant_indexed_clusters.csv') -> list:
    '''
    Main driver function that trains model on existing reviews, then outputs top-rated restaurants in user cluster
    '''
    # Get user inputs
    data = request.json
    user_cluster = data.get('user_cluster', 'Philadelphia, PA Area')
    user_selection = data.get('user_selection', [
        {"name": "Philly Foodworks", "food": "5", "time": "3", "service": "3"},
        {"name": "Ice Cave", "food": "3", "time": "5", "service": "3"},
        {"name": "Kims Restaurant", "food": "3", "time": "3", "service": "5"},
    ])
    
    reviews = pd.read_csv(reviews_path)  
    start = time.time()
    train_data, new_user, res_ids_in_cluster, senti_user_list, senti_item_list, senti_ratings_list, bus_ids_in_cluster = data_prep(reviews_data = reviews, user_cluster=user_cluster, user_selection=user_selection) 
    stop = time.time()
    print("Data prep took: ", stop - start, " seconds") # DATA PREP TAKES ~50 seconds

    num_users = len(train_data.userId.unique())
    num_items = len(train_data.resId.unique())

    ## MF PREDICTIONS ##
    start = time.time()
    mf_preds = get_mf_preds(num_users, num_items, train_data, new_user, res_ids_in_cluster, emb_size=100, epochs=5, lr=.1) ## can change model and model params in function
    stop = time.time()
    print("MF model took: ", stop - start, " seconds") # MF MODEL TAKES ~20 seconds
    
    ## SENTI MODEL PREDICTIONS ##
    start = time.time()
    senti_preds_df = get_senti_preds(senti_user_list, senti_item_list, senti_ratings_list, new_user, bus_ids_in_cluster, batch_size=500, testing=True) ## turn testing OFF to predict on whole cluster
    stop = time.time()
    print("Senti model took: ", stop - start, " seconds") # SENTI MODEL TAKES ~XX seconds

    # combine MF and senti model preds
    BETA = .6
    mf_preds_df = pd.DataFrame({
        'resId': res_ids_in_cluster.tolist(),
        'mf_pred': list(mf_preds.detach().numpy().reshape(-1))
    })    
    output = mf_preds_df.merge(reviews[['resId', 'business_id', 'business_name']].drop_duplicates()) # get business_id to join on senti model, and business name 
    output = output.merge(senti_preds_df)
    output['combined_pred'] = output['mf_pred'] * BETA + output['senti_pred'] * (1 - BETA)
    
    ## return top 3 business ids based on predicted rating
    output = output.groupby('business_name')['combined_pred'].nlargest(1).reset_index() # for multiple rest ids with same name, only keep top rated id
    user_recs = list(output.sort_values(by="combined_pred", ascending=False)['business_name'][0:3])

    return user_recs

