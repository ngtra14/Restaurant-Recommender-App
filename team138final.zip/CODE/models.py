import torch
import torch.nn as nn
import torch.nn.functional as F
from helper import train_epocs
from scipy.sparse import csr_matrix
from sklearn.preprocessing import LabelEncoder
from helper import torch_sentiment_predict_batch
import pandas as pd

class CollabFNet(nn.Module):
    def __init__(self, num_users, num_items, emb_size=100, n_hidden=10):
        super(CollabFNet, self).__init__()
        self.user_emb = nn.Embedding(num_users, emb_size)
        self.item_emb = nn.Embedding(num_items, emb_size)
        self.ff1 = nn.Linear(emb_size*2, n_hidden)
        self.ff2 = nn.Linear(n_hidden, 1)
        self.drop1 = nn.Dropout(0.1)
        
    def forward(self, u, v):
        U = self.user_emb(u)
        V = self.item_emb(v)
        x = F.relu(torch.cat([U, V], dim=1))
        x = self.drop1(x)
        x = F.relu(self.ff1(x))
        x = self.ff2(x)
        return x
    
class MF(nn.Module):
    def __init__(self, num_users, num_items, emb_size=100):
        super(MF, self).__init__()
        self.user_emb = nn.Embedding(num_users, emb_size)
        self.item_emb = nn.Embedding(num_items, emb_size)
        self.user_emb.weight.data.uniform_(0, 0.05)
        self.item_emb.weight.data.uniform_(0, 0.05)
        
    def forward(self, u, v):
        u = self.user_emb(u)
        v = self.item_emb(v)
        return (u*v).sum(1)   
    
def get_mf_preds(num_users, num_items, train_data, new_user, res_ids_in_cluster, emb_size, epochs, lr):
    '''
    Function to run model (can choose btwn MF, CollabFNet, etc.) and return predictions on restaurants in user cluster
    '''
    model = MF(num_users, num_items, emb_size=emb_size) # ~30 seconds runtime
    train_epocs(model, train_data, epochs=epochs, lr=lr, wd=1e-6)
    pred = model(new_user, res_ids_in_cluster) ## predict on user for restaurants in cluster

    return pred

def get_senti_preds(senti_user_list, senti_item_list, senti_ratings_list, new_user, bus_ids_in_cluster, batch_size, testing=False):
    '''
    Function to run senti model and return predictions on restaurants in user cluster
    '''
    user_encoder = LabelEncoder()
    item_encoder = LabelEncoder()

    encoded_users = user_encoder.fit_transform(senti_user_list)
    encoded_items = item_encoder.fit_transform(senti_item_list)

    # Define the number of users and items based on unique values
    num_users = len(set(encoded_users))
    num_items = len(set(encoded_items))

    # Create the sparse user-item matrix (CSR format) for efficient slicing
    user_item_matrix = csr_matrix(
        (senti_ratings_list, (encoded_users, encoded_items)), shape=(num_users, num_items)
    )

    # Generate prediction on restaurants in cluster for the new user
    user_batch = [new_user[0].item()] * len(bus_ids_in_cluster) # new user list
    item_batch = bus_ids_in_cluster  # restaurants in cluster to predict on 
    batch_size = batch_size
    senti_preds = []
    if testing: # if testing is True, then only predict for 1 batch to get results faster
        pred_length = batch_size
    else:
        pred_length = len(user_batch) # predict on entire cluster
    for i in range(0, pred_length, batch_size):
        print("Batch from " + str(i) + " to " + str(i + batch_size))
        user_sub_batch = user_batch[i:i + batch_size]
        item_sub_batch = item_batch[i:i + batch_size]
        # Process the current sub-batch and collect predictions
        sub_batch_predictions = torch_sentiment_predict_batch(user_sub_batch, item_sub_batch, user_encoder, item_encoder, user_item_matrix)
        senti_preds = senti_preds + sub_batch_predictions

    senti_preds_df = pd.DataFrame(senti_preds, columns=['user_id', 'business_id', 'senti_pred'])
    return senti_preds_df[['business_id', 'senti_pred']]