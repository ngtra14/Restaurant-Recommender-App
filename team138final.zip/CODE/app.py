from flask import Flask, render_template, request, jsonify
from views import views
from helper import get_nearest_cluster, rests_dd

app = Flask(__name__)
app.register_blueprint(views, url_prefix='/')

# Main route
@app.route("/")
def index():
    return render_template("index.html")

# API route
@app.route("/api/position", methods=["POST"])
def api_data():
    # Get user inputs
    data = request.json
    latitude = data["latitude"]
    longitude = data["longitude"]

    # Calling Cluster function based on closest cluster to user
    closest_cluster = get_nearest_cluster(latitude, longitude)

    # Generating names of 50 best restaurants from the cluster
    list_rests = rests_dd(closest_cluster)

    # SZ comment: Check out get_nearest_cluster function and rests_dd function
    response_data = {"cluster": list_rests, "cluster_name": closest_cluster}
    return jsonify(response_data)

if __name__ == "__main__":
    app.run(debug=True)
    
