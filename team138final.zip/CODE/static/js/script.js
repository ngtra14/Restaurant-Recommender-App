let cluster_name

// Get user location
function getUserLocation() {
    return new Promise((resolve, reject) => {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(
                (position) => {
                    const latitude = position.coords.latitude;
                    const longitude = position.coords.longitude;
                    resolve({ latitude, longitude });
                },
                (error) => {
                    reject(
                        "Error Code = " + error.code + " - " + error.message
                    );
                }
            );
        } else {
            reject("Geolocation is not supported by this browser.");
        }
    });
}

// Create recomdended element
function createElement(restaurantName, recomdendedElement) {
    
    // Create a container for each selected item
    const itemContainer = document.createElement("p");
    itemContainer.className = "my-2 fs-5";
    itemContainer.innerText = restaurantName

    recomdendedElement.appendChild(itemContainer)
}


window.onload = async () => {
    const buttonElement = document.getElementById("sendButton");
    const recomdendedElement = document.getElementById("user-recomendation");

    // Get location
    const location = await getUserLocation();
    const data = {
        latitude: location.latitude,
        longitude: location.longitude,
    };
    try {
        const response = await fetch("/api/position", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify(data),
        });
        const result = await response.json();

        // Populate dropdown with items from the array
        const dropdownElement = document.getElementById("itemDropdown");

        result.cluster.forEach((item) => {
            const option = document.createElement("option");
            option.value = item;
            option.text = item;
            dropdownElement.appendChild(option);
        });
        cluster_name = result.cluster_name

        dropdownElement.disabled = false;

        const selectedItemsContainer = document.getElementById(
            "selectedItemsContainer"
        );
        let selectedItems = new Set();

        dropdownElement.addEventListener("change", (event) => {
            const selectedValue = event.target.value;

            if (selectedItems.has(selectedValue)) {
                // If the item is already selected, unselect it
                selectedItems.delete(selectedValue);
            } else {
                // If not selected, check the count before adding
                if (selectedItems.size < 3) {
                    selectedItems.add(selectedValue);
                } else {
                    // If already three items are selected, reset the dropdown to prevent further selection
                    event.target.value = "";
                    alert("You can only select up to 3 items.");
                }
            }

            selectedItemsContainer.innerHTML = "";
            displaySelectedItems();
        });

        function displaySelectedItems() {
            selectedItems.forEach((item) => {
                // Create a container for each selected item
                const itemContainer = document.createElement("div");
                itemContainer.className = "card-body m-3";

                // Display the item name
                const itemTitle = document.createElement("h5");
                itemTitle.className = "card-title my-2";
                itemTitle.textContent = item;
                itemContainer.appendChild(itemTitle);

                // Create ranking inputs for each aspect
                const aspects = ["Food", "Time", "Service"];
                aspects.forEach((aspect) => {
                    const rankContainer = document.createElement("div");
                    rankContainer.className = "rank-container my-1";

                    const aspectLabel = document.createElement("label");
                    aspectLabel.textContent = `${aspect}`;
                    aspectLabel.className = "ranking";
                    
                    const rankInput = document.createElement("input");
                    rankInput.type = "number";
                    rankInput.min = 1;
                    rankInput.max = 5;
                    rankInput.className = "input-group-text";

                    rankContainer.appendChild(aspectLabel);
                    rankContainer.appendChild(rankInput);
                    itemContainer.appendChild(rankContainer);
                });

                selectedItemsContainer.appendChild(itemContainer);
            });
        }

        buttonElement.addEventListener("click", async () => {
            // Show spinner
            const spinnerElement = document.getElementById("loading-spinner")
	        spinnerElement.hidden = false;            

            // Create an array to store each item's details
            const items = [];

            // Select all elements with class `card-body` inside the `#selectedItemsContainer`
            document
                .querySelectorAll("#selectedItemsContainer .card-body")
                .forEach((card) => {
                    // Extract the name from the title
                    const name = card
                        .querySelector(".card-title")
                        .textContent.trim();

                    // Extract the ratings from each input field
                    const food = card.querySelector(
                        ".rank-container:nth-child(2) input"
                    ).value;
                    const time = card.querySelector(
                        ".rank-container:nth-child(3) input"
                    ).value;
                    const service = card.querySelector(
                        ".rank-container:nth-child(4) input"
                    ).value;

                    // Push an object with the extracted values into the array
                    items.push({ name, food, time, service });
                });

            console.log("items are sent back");

            // Send back to server
            const response = await fetch("/api/generate-recs", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({
                    user_cluster: cluster_name, // Add user cluster
                    user_selection: items
                }),
            });
            
            const result = await response.json();
            console.log(cluster_name);
            console.log(result);

            // Hide spinner
	        spinnerElement.hidden = true;

            // Create recommend restaurant
            result.forEach(restaurantName => createElement(restaurantName, recomdendedElement))
        });
    } catch (error) {
        console.error("Error:", error);
    }
};
