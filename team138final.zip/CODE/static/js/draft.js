function createDropdown() {
    const dropdownContainer = document.getElementById("dropdownContainer");

    // Create dropdown element
    const dropdown = document.createElement("select");
    dropdown.id = "itemDropdown";
    dropdown.disabled = false;

    // Add default option
    const defaultOption = document.createElement("option");
    defaultOption.value = "";
    defaultOption.text = "Select an item";
    dropdown.appendChild(defaultOption);

    // Populate dropdown with items
    result.response.forEach((item) => {
        const option = document.createElement("option");
        option.value = item;
        option.text = item;
        dropdown.appendChild(option);
    });

    // Add event listener for changes
    dropdown.addEventListener("change", addItem);

    // Append dropdown to container
    dropdownContainer.appendChild(dropdown);
}

// Function to handle item addition
function addItem() {
    const dropdown = document.getElementById("itemDropdown");
    const selectedItem = dropdown.value;

    if (
        selectedItem &&
        !selectedItems.includes(selectedItem) &&
        selectedItems.length < 3
    ) {
        selectedItems.push(selectedItem);
        displaySelectedItems();
    }

    // Disable dropdown if 3 items are selected
    if (selectedItems.length === 3) {
        dropdown.disabled = true;
    }
    dropdown.value = ""; // Reset dropdown selection
}

// Display selected items with ranking options
function displaySelectedItems() {
    const container = document.getElementById("selectedItemsContainer");
    container.innerHTML = ""; // Clear the container

    selectedItems.forEach((item) => {
        // Create a div for each selected item
        const itemDiv = document.createElement("div");
        itemDiv.className = "selected-item";
        itemDiv.innerHTML = `<strong>${item}</strong>`;

        // Create ranking dropdowns for each aspect
        ["Aspect 1", "Aspect 2", "Aspect 3"].forEach((aspect) => {
            const rankDropdown = document.createElement("select");
            rankDropdown.className = "rank-dropdown";
            rankDropdown.innerHTML = `
                <option value="">Rank ${aspect}</option>
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
            `;
            itemDiv.appendChild(rankDropdown);
        });

        // Append item div to container
        container.appendChild(itemDiv);
    });
}

