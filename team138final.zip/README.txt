# Description  
This tool integrates user-item collaborative filtering with sentiment analysis to provide personalized recommendations based 
on both historical behaviors and specific individual preferences. By leveraging aspect-based sentiments extracted from user 
reviews, the model identifies user inclinations toward food quality, service timeliness, and distinct taste profiles. 
This approach enables the delivery of dining suggestions that are not only relevant but also customized to meet users’ personal 
dining expectations.

# Installation and Starting  
This restaurant recommendation system app is built using Python and JavaScript.

## Prepare Environment
1. Install [Anaconda](https://www.anaconda.com/download).  
2. Create the environment: `conda create --name app_env python=3.12 -y`. 
3. Install dependencies with `requirements.txt`: `pip install -r requirements.txt`

## Download and Process Data
1. Download [data](https://www.kaggle.com/datasets/yelp-dataset/yelp-dataset/data) and unzip at `CODE/pre-process/*.json`
2. Download [sentimen-process](https://gtvault-my.sharepoint.com/:u:/g/personal/tdoan64_gatech_edu/EZsNYXQxMBpGgzEgjhxfLz4BdnLzVy60nHqMhl43BZwlgQ?e=VMHZze) 
and unzip at `CODE/sentiment-processed/`
3. Run the entire notebook `CODE/pre-process/data transforms pre-runtime.ipynb` 
4. `cd` to the app folder and start the virtual environment: `conda activate app_env`
5. launch the program: `python app.py`.  
6. Open [http://127.0.0.1:5000/](http://127.0.0.1:5000/) in your browser.  
7. Enable location permissions in your browser.  

# User Guide  
The user interface consists of two main sections. On the left panel, users input their opinions for three restaurants, 
rating three aspects—food, service, and time—on a scale of 1 to 5.

After submitting their preferences, the system generates recommendations for three restaurants based on the user's sentiment 
and preferences.
